import greenfoot.*;

public class Wombat extends Enemy
{
    private int jumpStrength = 150;
    private int jumpCounter = 0;
    private int jumpDelay = 10;
    private int fallSpeed = 0;
    private int acceleration = 1;
    private boolean isJumping = false;
    private GreenfootImage right = new GreenfootImage("wombat1.png");
    private GreenfootImage left = new GreenfootImage("wombat2.png");
    private int velocityX;
    private int velocityY;

    public void act()
    {
        move();
        drop();
        checkCollision();
        
        // Determine the direction of the player relative to this actor
        Player player = getWorld().getObjects(Player.class).get(0);
        int playerX = player.getX();
        int thisX = getX();
        int direction = (playerX > thisX) ? 0 : 180;

        // Set the image based on the direction
        if (direction == 0)
        {
            setImage(right);
        }
        else
        {
            setImage(left);
        }

        // Jump if the player is above the Wombat and the Wombat is on the ground
        if (jumpCounter == 0 && player.getY() < getY() && onGround())
        {
            jump();
        }

        // Update the jump counter and delay
        if (jumpCounter > 0)
        {
            jumpCounter--;
        }
        if (jumpDelay > 0)
        {
            jumpDelay--;
        }
    }

    public boolean onGround()
    {
        Actor ground = getOneObjectAtOffset(0, getImage().getHeight() / 2, Object.class);
        return ground != null;
    }

 private void jump() {
    Player player = getWorld().getObjects(Player.class).get(0);
    Actor platform = getOneObjectAtOffset(0, player.getImage().getHeight() / 2, Object.class);

    if (platform != null && player.getY() <= platform.getY()) {
        // Jump on top of the platform if the player is on it
        int newX = platform.getX();
        int newY = platform.getY() - platform.getImage().getHeight() / 2 - getImage().getHeight() / 2;
        setLocation(newX, newY);
    } else {
        // Regular jump towards the player
        int newX = getX() + (getMovement() / 2);
        int newY = getY() - jumpStrength;
        setLocation(newX, newY);
    }

    // Set the jump counter and delay
    jumpCounter = jumpStrength;
    jumpDelay = 100;
    isJumping = true;
 }






    public void drop()
    {
        if (isJumping)
        {
            // Continue jumping by applying a negative fall speed
            setLocation(getX(), getY() - fallSpeed);
            fallSpeed--;
            
            // Check if the jump has ended
            if (fallSpeed <= 0 && onGround())
            {
                isJumping = false;
                fallSpeed = 0;
            }
        }
        else if (!onGround())
        {
            // Fall if not on the ground
            setLocation(getX(), getY() + fallSpeed);
            fallSpeed = Math.min(fallSpeed + acceleration, 10);
        }
    }
    
    public void move()
    {
        // Determine the direction of the player relative to this actor
        Player player = getWorld().getObjects(Player.class).get(0);
        int playerX = player.getX();
        int thisX = getX();
        int direction = (playerX > thisX) ? 0 : 180;

        // Move towards the player
        if (direction == 0)
        {
            setLocation(getX() + 1, getY());
        }
        else
        {
            setLocation(getX() - 1, getY());
        }
    }

    public int getMovement()
 {
    // Determine the direction of the player relative to this actor
    Player player = getWorld().getObjects(Player.class).get(0);
    int playerX = player.getX();
    int thisX = getX();
    int direction = (playerX > thisX) ? 0 : 180;

    // Calculate the movement speed based on the direction and distance to the player
    int distance = Math.abs(playerX - thisX);
    int movement = (int) (distance / 25.0);
    movement = Math.max(movement, 1);
    movement = (direction == 0) ? movement : -movement;
    return movement;
 }
 

 private void checkCollision() {
    for (Wombat wombat : getIntersectingObjects(Wombat.class)) {
        // calculate distance between the two wombats
        double distanceX = getX() - wombat.getX();
        double distanceY = getY() - wombat.getY();
        double distance = Math.sqrt(distanceX * distanceX + distanceY * distanceY);

        // if the distance is less than the sum of their radii, they are colliding
        if (distance < 2 * getImage().getWidth()) {
            // calculate the angle between the two wombats
            double angle = Math.atan2(distanceY, distanceX);

            // calculate the amount of overlap between the two wombats
            double overlap = 2 * getImage().getWidth() - distance;

            // move both wombats away from each other
            int moveX = (int)(overlap * Math.cos(angle));
            int moveY = (int)(overlap * Math.sin(angle));
            setLocation(getX() + moveX, getY() + moveY);
            wombat.setLocation(wombat.getX() - moveX, wombat.getY() - moveY);


        }
    }
 }
}