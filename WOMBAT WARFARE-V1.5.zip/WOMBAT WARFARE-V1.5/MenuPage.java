import greenfoot.*;

public class MenuPage extends World {
    private GreenfootSound menuMusic;

    public MenuPage() {    
        super(560, 530, 1);
        prepare();
    }

    private void prepare() {
        // Set the background image to "WombatWarfareCover.png"

        // Add the StartButton to the world
        StartButton startButton = new StartButton();
        addObject(startButton, getWidth() / 2, getHeight() / 2);

        // Initialize the menu music
        menuMusic = new GreenfootSound("menuMusic.mp3");
        startButton.setLocation(280,404);

    }

    public void started() {
        // Start playing the menu music
        menuMusic.playLoop();
    }

    public void stopped() {
        // Stop playing the menu music
        menuMusic.stop();
    }

    public void startGame() {
    // Stop playing the menu music
    menuMusic.stop();
    
    // Switch to the MyWorld game
    Greenfoot.setWorld(new WorldOne());
}
}
