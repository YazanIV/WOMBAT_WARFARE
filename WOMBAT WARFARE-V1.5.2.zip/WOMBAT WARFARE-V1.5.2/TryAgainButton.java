import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class TryAgainButton extends Actor
{
    private GreenfootImage normalImage;
    private GreenfootImage highlightedImage;

    public TryAgainButton() {
        // Set the normal and highlighted images
        normalImage = new GreenfootImage("TryAgain.png");
        highlightedImage = new GreenfootImage("TryAgain_Highlighted.png");

        // Set the initial image to the normal image
        setImage(normalImage);
    }

    public void act() {
        // Check if the mouse is hovering over the button
        if (Greenfoot.mouseMoved(this)) {
            setImage(highlightedImage);
        } else if (Greenfoot.mouseMoved(null)) {
            setImage(normalImage);
        }

        // Check if the button has been clicked
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.setWorld(new MenuPage());
            GameOverWorld gowrld= (GameOverWorld) getWorld();
            gowrld.stopped();
        }
    }
}
