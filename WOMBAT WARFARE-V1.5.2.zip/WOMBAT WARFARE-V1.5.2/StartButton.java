import greenfoot.*;

public class StartButton extends Actor {
    private GreenfootImage normalImage;
    private GreenfootImage highlightedImage;

    public StartButton() {
        // Set the normal and highlighted images
        normalImage = new GreenfootImage("StartButton.png");
        highlightedImage = new GreenfootImage("StartButton_Highlighted.png");

        // Set the initial image to the normal image
        setImage(normalImage);
    }

    public void act() {
        // Check if the mouse is hovering over the button
        if (Greenfoot.mouseMoved(this)) {
            setImage(highlightedImage);
        } else if (Greenfoot.mouseMoved(null)) {
            setImage(normalImage);
        }

        // Check if the button has been clicked
        if (Greenfoot.mouseClicked(this)) {
            MenuPage menuPage = (MenuPage) getWorld();
            menuPage.startGame();
        }
    }
}
