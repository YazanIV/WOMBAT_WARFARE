/**
 * Write a description of class Vector2D here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Vector2D  
{
    private double x;
    private double y;
    

    public Vector2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public Vector2D() {
        this(0, 0);
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getMagnitude() {
        return Math.sqrt(x * x + y * y);
    }

    public void setMagnitude(double magnitude) {
        double angle = getAngle();
        x = Math.cos(angle) * magnitude;
        y = Math.sin(angle) * magnitude;
    }

    public double getAngle() {
        return Math.atan2(y, x);
    }

    public void setAngle(double angle) {
        double magnitude = getMagnitude();
        x = Math.cos(angle) * magnitude;
        y = Math.sin(angle) * magnitude;
    }

    public void add(Vector2D other) {
        x += other.x;
        y += other.y;
    }

    public void subtract(Vector2D other) {
        x -= other.x;
        y -= other.y;
    }

    public void multiply(double scalar) {
        x *= scalar;
        y *= scalar;
    }

    public void divide(double scalar) {
        x /= scalar;
        y /= scalar;
    }

    public Vector2D normalized() {
        double magnitude = getMagnitude();
        if (magnitude != 0) {
            return new Vector2D(x / magnitude, y / magnitude);
        } else {
            return new Vector2D();
        }
    }

    public double dot(Vector2D other) {
        return x * other.x + y * other.y;
    }

    public double angleBetween(Vector2D other) {
        return Math.acos(dot(other) / (getMagnitude() * other.getMagnitude()));
    }

    public Vector2D copy() {
        return new Vector2D(x, y);
    }
}
