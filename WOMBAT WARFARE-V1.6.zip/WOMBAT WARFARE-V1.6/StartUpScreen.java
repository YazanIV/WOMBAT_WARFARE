import greenfoot.*;

public class StartUpScreen extends World {
    private int counter = 0;
    private GreenfootSound startUp = new GreenfootSound("Startup.wav");
    public StartUpScreen() {
        super(730, 400, 1);
        
    }
    
    public void act() {
        if (counter < 390) {
            startUp.playLoop();
            counter++;
        } else {
            Greenfoot.setWorld(new MenuPage());// Transition to the game world
            startUp.stop();
        }
    }
}
