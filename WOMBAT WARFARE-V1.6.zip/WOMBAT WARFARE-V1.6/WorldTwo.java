import greenfoot.*;
import java.util.List;

public class WorldTwo extends World
{

    public WorldTwo()
    {    
        super(800, 600, 1);

        addObject(new Player(), 32, 540);

        // Add platforms
        addObject(new Object(), 162, 200);
        addObject(new Object(), 224, 200);
        addObject(new Object(), 286, 200);
        addObject(new Object(), 349, 200);

        addObject(new Object(), 462, 325);
        addObject(new Object(), 524, 325);
        addObject(new Object(), 586, 325);
        addObject(new Object(), 649, 325);

        addObject(new Object(), 162, 450);
        addObject(new Object(), 224, 450);
        addObject(new Object(), 286, 450);
        addObject(new Object(), 349, 450);

        // Add floor
        addObject(new Object(), 28, 600);
        addObject(new Object(), 90, 600);
        addObject(new Object(), 152, 600);
        addObject(new Object(), 214, 600);
        addObject(new Object(), 276, 600);
        addObject(new Object(), 338, 600);
        addObject(new Object(), 400, 600);
        addObject(new Object(), 462, 600);
        addObject(new Object(), 524, 600);
        addObject(new Object(), 586, 600);
        addObject(new Object(), 648, 600);
        addObject(new Object(), 710, 600);
        addObject(new Object(), 772, 600);

        // Add wombats
        addObject(new Wombat(), 256, 396);
        addObject(new Wombat(), 560, 277);
        
        addObject(new Wombat(), 594, 540);
        addObject(new Wombat(), 756, 540);

        prepare();
    }

    public void act() {
        transitionToGameOver();
         if (getObjects(Wombat.class).isEmpty()) {
        // Check if the player has reached the right side of the screen
        Player player = getObjects(Player.class).get(0);
        if (player.getX() >= getWidth() - player.getImage().getWidth() / 2) {
            // Stop the music
            

            // Transition to WorldTwo
            Greenfoot.setWorld(new WorldThree());
            stopped();
        }
    }
    }

    
    public void transitionToGameOver() {
        List<Player> player = getObjects(Player.class);
        if (player.isEmpty()) {
            stopped();
            Greenfoot.setWorld(new GameOverWorld());
        }
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
