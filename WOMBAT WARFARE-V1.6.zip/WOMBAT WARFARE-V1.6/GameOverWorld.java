import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Write a description of class GameOverWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameOverWorld extends World
{
    private GreenfootSound levelOneMusic=new GreenfootSound("Level1.mp3");
    private GreenfootSound gameOver;    
    
    /**
     * Constructor for objects of class GameOverWorld.
     * 
     */
    public GameOverWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(560, 530, 1); 
        TryAgainButton tryagain = new TryAgainButton();
        addObject(tryagain, getWidth() / 2, 350 );
        prepare();
        
        
    }
    private void prepare(){
     
     started();
    }
    
    public void started(){
        gameOver=new GreenfootSound("GameOver2.wav");
        gameOver.play();
    }
    public void stopped(){
        gameOver.pause();
    }
    }

    
