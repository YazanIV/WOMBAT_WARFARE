import greenfoot.*;
import java.util.List;

public class WorldThree extends World {
    private GreenfootSound Win= new GreenfootSound("Victory.wav");
    public GreenfootSound levelOneMusic;
    public WorldThree() {
        super(800, 600, 1);
        
        prepare();
    }

    private void prepare() {


        // Add wombats on the platform
        addObject(new Wombat(), 400,425);
        addObject(new Wombat(), 462,425);
        addObject(new Wombat(), 524,425);
        // Add the third wombat below the platform
        

        // Add the player
        addObject(new Player(), 32, 540);

        // Add any additional objects or elements specific to WorldThree
        addObject(new Object(), 28, 600);
        addObject(new Object(), 90, 600);
        addObject(new Object(), 152, 600);
        addObject(new Object(), 214, 600);
        addObject(new Object(), 276, 600);
        addObject(new Object(), 338, 600);
        addObject(new Object(), 400, 600);
        addObject(new Object(), 462, 600);
        addObject(new Object(), 524, 600);
        addObject(new Object(), 586, 600);
        addObject(new Object(), 648, 600);
        addObject(new Object(), 710, 600);
        addObject(new Object(), 772, 600);  
        addObject(new Object(), 338, 475);
        addObject(new Object(), 400, 475);
        addObject(new Object(), 462, 475);
        addObject(new Object(), 524, 475);
        // Show the text and arrow
        GreenfootImage textImage = new GreenfootImage("SAFE ZONE", 24, Color.BLUE, null);
        drawArrow(400, 80, 750, 80, 20);
        getBackground().drawImage(textImage, (getWidth() - textImage.getWidth()) / 2, 20);
               

        act();
        }

    public void act() {
        transitionToGameOver();
        
         if (getObjects(Wombat.class).isEmpty()) {
        // Check if the player has reached the right side of the screen
        Player player = getObjects(Player.class).get(0);
        if (player.getX() >= getWidth() - player.getImage().getWidth() / 2) {
            // Stop the music
            

            // Transition to WorldTwo
            stopped();
            Greenfoot.setWorld(new WinWorld());
            Win.play();
        }
    }
        
    }
    
    

    public void transitionToGameOver() {
        List<Player> player = getObjects(Player.class);
        if (player.isEmpty()) {
            stopped();
            Greenfoot.setWorld(new GameOverWorld());
        }
    }
    private void drawArrow(int startX, int startY, int endX, int endY, int arrowSize) {
        // Draw the line
        getBackground().drawLine(startX, startY, endX, endY);
        
        // Draw the arrowhead
        int dx = endX - startX;
        int dy = endY - startY;
        double angle = Math.atan2(dy, dx);
        int arrowX = endX - (int) (arrowSize * Math.cos(angle - Math.PI / 6));
        int arrowY = endY - (int) (arrowSize * Math.sin(angle - Math.PI / 6));
        getBackground().drawLine(endX, endY, arrowX, arrowY);
        arrowX = endX - (int) (arrowSize * Math.cos(angle + Math.PI / 6));
        arrowY = endY - (int) (arrowSize * Math.sin(angle + Math.PI / 6));
        getBackground().drawLine(endX, endY, arrowX, arrowY);
    }
}

