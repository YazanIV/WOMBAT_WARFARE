import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bullet extends Player
{
     private int speed = 5;  // the speed of the bullet
    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act(){ 
     move(speed);
        if (isAtEdge()) { // check if bullet hits border of the world
            getWorld().removeObject(this); // remove bullet object from world
        }
        else {
            checkForCollision(); // check for collision with Wombat object
        }
    }
    
    private void checkForCollision() {
        Wombat wombat = (Wombat) getOneIntersectingObject(Wombat.class);
        if (wombat != null) { // check if bullet hits Wombat object
            getWorld().removeObject(wombat); // remove wombat object from world
            getWorld().removeObject(this); // remove bullet object from world
        }
    }
}
